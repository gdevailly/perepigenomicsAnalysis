setwd("/groups2/joshi_grp/guillaume/cascade/data/wgbs/roadmap")
library(dplyr)
library(plotrix)
library(seqplots)
library(readr)
library(svglite)
library(parallel)

source("../../../Rscripts/6-plotingFunctions.R")

metadata <- read_tsv("EG.mnemonics.name.txt", col_names = FALSE)
colnames(metadata) <- c("id", "short", "name")

myProms <- "../../../../annotationData/gencode.v24.annotation.hg19.middleTSStranscript.light.autosomes.bed"

roadmapExp <- list(
    pc = read_tsv("../../../../otherProject/ChIP_heatmap/data/roadmap/57epigenomes.RPKM.pc"),
    nc = read_tsv("../../../../otherProject/ChIP_heatmap/data/roadmap/57epigenomes.RPKM.nc"),
    rb = read_tsv("../../../../otherProject/ChIP_heatmap/data/roadmap/57epigenomes.RPKM.rb")
)
roadmapExp <- do.call(rbind, roadmapExp)

refTable <- read_tsv(
    "../../../../annotationData/gencode.v24.annotation.hg19.middleTSStranscript.bed",
    col_names = FALSE
)
colnames(refTable) <- c("chr", "start", "end", "gene_id", "score", "strand", "gene_type", "symbol")
refTable$gene_id <-  sub("\\.[0-9]*", "", refTable$gene_id)

metadata$id[!metadata$id %in% colnames(roadmapExp)] # missing E008, E017, E021, E022, check newer data?
metadata <- filter(metadata, id %in% colnames(roadmapExp))

adundant_gene_types <- dplyr::select(refTable, gene_type) %>%
    dplyr::group_by(gene_type) %>%
    dplyr::summarise(n = n()) %>%
    dplyr::filter(n >= 200) %>%
    dplyr::select(gene_type) %>%
    unlist %>%
    unname
adundant_gene_types <- adundant_gene_types[-12] # TEC genes are mostly absent from data


# TSS ------------

plotBetterWgbsDataFor <- function(i, npix_height = 600) {
        
    dataForPlot <- extractAndPrepareDataFor(
        metadata$id[i],
        myProms,
        roadmapExp,
        refgenome = "hg19",
        bin = 100L,
        rm0 = TRUE,
        xmin = 2500L, xmax = 2500L, type = "pf",
        add_heatmap = TRUE,
        verbose = FALSE
    ) %>% addGeneTypeInfo(refTable)
    
    zlim1 <- c(0, 20)
    zlim4 <- c(10, 50)
    if(metadata$id[i] %in% c(
        "E005", "E007", "E011", "E012", "E013", "E016", "E065", "E066", "E070", "E071", "E095", "E106"
    )) zlim4 <- c(30, 100)
    if(metadata$id[i] %in% c("E084", "E085")) {
        zlim1 <- c(0, 10)
        zlim4 <- c(0, 20)
    }
    zlims <- list(zlim1, c(0,1), c(1, 4), zlim4)
    
    for(j in adundant_gene_types) {
        if(!file.exists(paste0("../../../appPlots/tss/wgbs/", j))) {
            dir.create(paste0("../../../appPlots/tss/wgbs/", j))
        }
        png(
            file = paste0(
                "../../../appPlots/tss/wgbs/", j, "/", metadata$id[i], ".png"
            ),
            width = 8.3, height = 5.8, units = "in", res = 300, pointsize = 13
        )
        plotMetricAndProfile(
            dplyr::filter(dataForPlot, gene_type == j),
            zlims  = zlims,
            raster = TRUE,
            title = "",
            tints  = c("red", "blue", "purple", "sienna4"),
            withGeneType = FALSE,
            npix_height = npix_height
        )
        dev.off()
    }
    
    # adding gene type information
    geneType <- rep("other", nrow(dataForPlot))
    geneType[which(dataForPlot$gene_type == "protein_coding")] <- "protein coding"
    geneType[which(grepl("pseudogene", dataForPlot$gene_type, fixed = TRUE))] <- "pseudogene"
    geneType[which(grepl("RNA", dataForPlot$gene_type, fixed = TRUE))] <- "RNA gene"
    dataForPlot$gene_type <- geneType
    
    if(!file.exists(paste0("../../../appPlots/tss/wgbs/all/"))) {
        dir.create(paste0("../../../appPlots/tss/wgbs/all/"))
    }
    png(
        file = paste0(
            "../../../appPlots/tss/wgbs/all/", metadata$id[i], ".png"
        ),
        width = 8.3, height = 5.8, units = "in", res = 300, pointsize = 13
    )
    plotMetricAndProfile(
        dataForPlot,
        zlims  = zlims,
        raster = TRUE,
        title = "",
        tints  = c("red", "blue", "purple", "sienna4"),
        withGeneType = TRUE,
        npix_height = npix_height
    )
    dev.off()
    
    message(paste(metadata$id[i], "is done!"))
}

t0 <- Sys.time() # 
mclapply(
    seq_len(nrow(metadata)),
    plotBetterWgbsDataFor,
    mc.cores = 2 
) %>% invisible
Sys.time() - t0

# TES ----------------------
TES <- "../../../../annotationData/gencode.v24.annotation.hg19.middleTES.light.autosomes.bed"

plotBetterWgbsDataTESFor <- function(i, npix_height = 600) {
    
    dataForPlot <- extractAndPrepareDataFor(
        metadata$id[i],
        TES,
        roadmapExp,
        refgenome = "hg19",
        bin = 100L,
        rm0 = TRUE,
        xmin = 2500L, xmax = 2500L, type = "ef",
        add_heatmap = TRUE,
        verbose = FALSE
    ) %>% addGeneTypeInfo(refTable)
    
    zlim1 <- c(0, 20)
    zlim4 <- c(10, 50)
    if(metadata$id[i] %in% c(
        "E005", "E007", "E011", "E012", "E013", "E016", "E065", "E066", "E070", "E071", "E095", "E106"
    )) zlim4 <- c(30, 100)
    if(metadata$id[i] %in% c("E084", "E085")) {
        zlim1 <- c(0, 10)
        zlim4 <- c(0, 20)
    }
    zlims <- list(zlim1, c(0,1), c(1, 4), zlim4)
    
    for(j in adundant_gene_types) {
        if(!file.exists(paste0("../../../appPlots/tes/wgbs/", j))) {
            dir.create(paste0("../../../appPlots/tes/wgbs/", j))
        }
        png(
            file = paste0(
                "../../../appPlots/tes/wgbs/", j, "/", metadata$id[i], ".png"
            ),
            width = 8.3, height = 5.8, units = "in", res = 300, pointsize = 13
        )
        plotMetricAndProfile(
            dplyr::filter(dataForPlot, gene_type == j),
            zlims  = zlims,
            raster = TRUE,
            title = "",
            tints  = c("red", "blue", "purple", "sienna4"),
            xlabels = c("-2.5kb", "TES", "+2.5kb"),
            withGeneType = FALSE,
            npix_height = npix_height
        )
        dev.off()
    }
    
    # adding gene type information
    geneType <- rep("other", nrow(dataForPlot))
    geneType[which(dataForPlot$gene_type == "protein_coding")] <- "protein coding"
    geneType[which(grepl("pseudogene", dataForPlot$gene_type, fixed = TRUE))] <- "pseudogene"
    geneType[which(grepl("RNA", dataForPlot$gene_type, fixed = TRUE))] <- "RNA gene"
    dataForPlot$gene_type <- geneType
    
    if(!file.exists(paste0("../../../appPlots/tes/wgbs/all/"))) {
        dir.create(paste0("../../../appPlots/tes/wgbs/all/"))
    }
    png(
        file = paste0(
            "../../../appPlots/tes/wgbs/all/", metadata$id[i], ".png"
        ),
        width = 8.3, height = 5.8, units = "in", res = 300, pointsize = 13
    )
    plotMetricAndProfile(
        dataForPlot,
        zlims  = zlims,
        raster = TRUE,
        title = "",
        tints  = c("red", "blue", "purple", "sienna4"),
        xlabels = c("-2.5kb", "TES", "+2.5kb"),
        withGeneType = TRUE,
        npix_height = npix_height
    )
    dev.off()
    
    message(paste(metadata$id[i], "is done!"))
}

t0 <- Sys.time() # 12 minutes
mclapply(
    seq_len(nrow(metadata)),
    plotBetterWgbsDataTESFor,
    mc.cores = 4 
) %>% invisible
Sys.time() - t0

