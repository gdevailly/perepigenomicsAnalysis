
extractGeneWiseDataForHistone <- function(
    geneName,
    dataList,
    windows = c("X.500", "X.400", "X.300", "X.200", "X.100", "X0", "X100", "X200", "X300", "X400", "X500") # middle 11 windows when windows go from 1 to 51
) {
    data_frame(
        cell_type = names(dataList),
        exp = vapply(
            dataList,
            function(x) filter(x, gene_id == geneName)$exp,
            0
        ),
        HisMod = vapply(
            dataList,
            function(x) {
                geneData <- filter(x, gene_id == geneName)
                geneData <- geneData[, colnames(geneData) %in% paste0("HisMod", windows)]
                rowMeans(geneData, na.rm = TRUE)
            },
            0
        ),
        Input = vapply(
            dataList,
            function(x) {
                geneData <- filter(x, gene_id == geneName)
                geneData <- geneData[, colnames(geneData) %in% paste0("Input", windows)]
                rowMeans(geneData, na.rm = TRUE)
            },
            0
        )
    )
}

