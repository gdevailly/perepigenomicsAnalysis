# donload 2016-05-02
# from http://epigenomesportal.ca/ihec/download.html?as=1&i=4&ctc=1&hubId=4134 file https://www.encodeproject.org/files/ENCFF001ZIA/@@download/ENCFF001ZIA.bigBed?proxy=true
# bash
../../../../programmes/bigBedToBed ENCFF001ZIA.bigBed ENCFF001ZIA.bed
wc -l ENCFF001ZIA.bed # 51.361.578
# building three coverages: CpG per window, mCpG per window, mean mCpG/CpG per window
# using bedtool
