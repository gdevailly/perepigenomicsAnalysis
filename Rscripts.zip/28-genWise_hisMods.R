setwd("/groups2/joshi_grp/guillaume/cascade/data/")

source("../Rscripts/6-plotingFunctions.R")
source("../Rscripts/11-geneWiseFunctions.R")
source("../Rscripts/20-functions_for_histoneMarks.R")
source("../Rscripts/29-geneWiseFunctions_hisMods.R")

library(readr)
library(parallel)
library(purrr)

# metadata building
metadata <- read_tsv("wgbs/roadmap/EG.mnemonics.name.txt", col_names = FALSE)
colnames(metadata) <- c("id", "short", "name")

myProms <- "../../annotationData/gencode.v24.annotation.hg19.middleTSStranscript.light.autosomes.bed"

roadmapExp <- list(
    pc = read_tsv("../../otherProject/ChIP_heatmap/data/roadmap/57epigenomes.RPKM.pc"),
    nc = read_tsv("../../otherProject/ChIP_heatmap/data/roadmap/57epigenomes.RPKM.nc"),
    rb = read_tsv("../../otherProject/ChIP_heatmap/data/roadmap/57epigenomes.RPKM.rb")
)
roadmapExp <- do.call(rbind, roadmapExp)

refTable <- read_tsv(
    "../../annotationData/gencode.v24.annotation.hg19.middleTSStranscript.bed",
    col_names = FALSE
)
colnames(refTable) <- c("chr", "start", "end", "gene_id", "score", "strand", "gene_type", "symbol")
refTable$gene_id <-  sub("\\.[0-9]*", "", refTable$gene_id)
metadata$id[!metadata$id %in% colnames(roadmapExp)] # missing E008, E017, E021, E022, check newer data?
metadata <- filter(metadata, id %in% colnames(roadmapExp))

tss_table <- read_tsv(myProms, col_names = FALSE, progress = FALSE)
colnames(tss_table) <- c("chr", "start", "end", "name", "score", "strand")

# histone ------------
hisFiles <- data_frame(
    file = list.files("histone/") %>%
        grep(".gz$", ., value = TRUE),
    name = gsub(".tagAlign.gz", "", file, fixed = TRUE)
)
hisFiles <- bind_cols(
    hisFiles,
    strsplit(hisFiles$name, "-") %>%
        map_df(~data_frame(cellCode = .x[1], ChIP = .x[2]))
)
his_md <- left_join(
    dplyr::filter(hisFiles, !ChIP %in% c("DNase", "DNaseControl", "Input")),
    dplyr::filter(hisFiles, ChIP == "Input") %>%
        dplyr::select(file, cellCode) %>%
        dplyr::rename(input_file = file),
    by = "cellCode"
)

myHisMods <- names(table(his_md$ChIP)[table(his_md$ChIP) > 1])

# preparing data ------------------
preparDataFor <- function(thisHisMod) { # unpure

    mdForThisHisMod <- dplyr::filter(his_md, ChIP == thisHisMod)

    dataForThisHisMod <- mclapply(
        seq_len(nrow(mdForThisHisMod)),
        function(i) {
            hisModData <- prepareHisModData(i, tssAnno = tss_table, metadataTable = mdForThisHisMod, expressionTable = roadmapExp) %>%
                addGeneTypeInfo(refTable)
            message(paste(mdForThisHisMod$name[i], "done!"))
            return(hisModData)
        },
        mc.cores = 12
    )
    names(dataForThisHisMod) <- mdForThisHisMod$name

    t0 <- Sys.time()
    geneWiseData <- mclapply(
        dataForThisHisMod[[1]]$gene_id,
        function(x) extractGeneWiseDataForHistone(x, dataForThisHisMod),
        mc.cores = 24
    )
    Sys.time() - t0
    names(geneWiseData) <- dataForThisHisMod[[1]]$gene_id

    assign(thisHisMod, geneWiseData)
    save(list = thisHisMod, file = paste0("Rdata/geneWiseData_tss_", thisHisMod, ".RData"))

    return(NULL)
}

walk(myHisMods, preparDataFor)


t0 <- Sys.time()






dataForAllSamples <- mclapply(
    seq_len(nrow(metadata)),
    function(i) {
        hisModData <- prepareHisModData(i, tssAnno = tss_table, metadataTable = his_md, expressionTable = roadmapExp) %>%
            addGeneTypeInfo(refTable)

        dataForPlot <- extractAndPrepareDataFor(
            metadata$id[i],
            myProms,
            roadmapExp,
            refgenome = "hg19",
            bin = 100L,
            rm0 = TRUE,
            xmin = 2500L, xmax = 2500L, type = "pf",
            add_heatmap = TRUE,
            verbose = FALSE
        )
        dataForPlot <- addGeneTypeInfo(dataForPlot, refTable)
        message(paste(metadata$id[i], "done!"))
        return(dataForPlot)
    },
    mc.cores = 33, mc.preschedule = FALSE
)
Sys.time() - t0 # 2 minutes
names(dataForAllSamples) <- metadata$short
