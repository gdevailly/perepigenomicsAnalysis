# 2016-11-04
# downloaded from http://egg2.wustl.edu/roadmap/data/byDataType/rna/expression/:
57epigenomes.exn.RPKM.rb.gz       57epigenomes.RPKM.pc.gz
57epigenomes.exon.RPKM.nc.gz      57epigenomes.RPKM.rb.gz
57epigenomes.exon.RPKM.pc.gz      EG.name.txt
57epigenomes.RPKM.intronic.pc.gz  Ensembl_v65.Gencode_v10.ENSG.gene_info
57epigenomes.RPKM.nc.gz
# README: http://egg2.wustl.edu/roadmap/data/byDataType/rna/README
local position: /groups2/joshi_grp/guillaume/cascade/data/rnaseq/roadmap

