setwd("/groups2/joshi_grp/guillaume/cascade/")

library(tidyverse)

availablePng <- list.files("appPlots", recursive = TRUE, full.names = TRUE)
availablePng <- strsplit(availablePng, "/", fixed = TRUE) %>%
    map_df(~tibble(
        feature = .x[2],
        assay = .x[3],
        gene_type = if_else(feature == "exons", NA_character_, .x[4]),
        metric = if_else(feature == "exons", "exon FPKM", "gene FPKM"),
        cell = strsplit(.x[5], ".", fixed = TRUE)[[1]][1]
    ))

write_tsv(availablePng, "app/data/availablePng.tsv")

map(availablePng, unique)

myDictionary <- c(
    tss = "TSS",
    tes = "TES",
    dnase1 = "DNAse 1",
    wgbs = "WGBS"
)
myDictionary <- tibble(inWord = names(myDictionary), outWord = myDictionary)
cells <- read_tsv("metadata_33samples.txt")
cell_dic <- tibble(
    inWord = cells$id,
    outWord = cells$name
)
myDictionary <- bind_rows(myDictionary, cell_dic)
write_tsv(myDictionary, "app/data/dictionary.tsv")

